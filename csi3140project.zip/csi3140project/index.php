<html>
	<head>
		<title>PHP Test</title>
	</head>
	<body>
	<?php echo '<p>Hello World</p>'; ?>
	<?php echo '<p>This indicates that the PHP is working</p>'; ?>
	</body>
</html>